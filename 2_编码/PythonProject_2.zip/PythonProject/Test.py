import sys
import cv2
import os
import numpy as np
import time
from sklearn.cluster import KMeans  # 使用sklearn中的KMeans
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QFileDialog
# 限制线程数，避免内存泄漏警告
os.environ["OMP_NUM_THREADS"] = "1"

class ImageMatcher(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("图像匹配")
        self.setGeometry(100, 100, 800, 600)

        self.layout = QVBoxLayout()

        # 按钮和标签
        self.select_folder_button = QPushButton("选择文件夹")
        self.select_folder_button.clicked.connect(self.select_folder)
        self.layout.addWidget(self.select_folder_button)

        self.select_button = QPushButton("选择待匹配图像")
        self.select_button.clicked.connect(self.select_image)
        self.layout.addWidget(self.select_button)

        self.result_label = QLabel("匹配结果将显示在这里")
        self.layout.addWidget(self.result_label)

        self.time_label = QLabel("匹配时间：")
        self.layout.addWidget(self.time_label)

        self.setLayout(self.layout)

        self.folder_path = None  # 用来存储选择的文件夹路径
        self.dictionary = None   # 视觉词典

    def select_folder(self):
        # 选择文件夹路径
        folder = QFileDialog.getExistingDirectory(self, "选择文件夹")
        if folder:
            self.folder_path = folder
            print(f"已选择文件夹：{self.folder_path}")
        else:
            print("未选择文件夹")

    def select_image(self):
        try:
            if not self.folder_path:
                self.result_label.setText("请先选择文件夹！")
                return

            # 选择待匹配图像
            options = QFileDialog.Options()
            file, _ = QFileDialog.getOpenFileName(self, "选择图像", self.folder_path, "Images (*.png *.xpm *.jpg);;All Files (*)", options=options)

            if not file:
                print("未选择文件")
                return

            # 选择待匹配的图像
            img1 = cv2.imread(file, cv2.IMREAD_GRAYSCALE)
            if img1 is None:
                print(f"无法读取图像: {file}")
                return

            # 如果还没有构建视觉词典，则从文件夹中构建词典
            if self.dictionary is None:
                self.build_dictionary(self.folder_path)

            # 使用ORB提取特征并生成向量
            start_time = time.time()
            img1_vector = self.get_feature_vector(img1)
            end_time = time.time()
            match_time = end_time - start_time

            # 遍历文件夹中的所有图像，计算匹配分数
            best_match_image, best_match_score = self.find_best_match(img1_vector, self.folder_path)

            # 显示最匹配的图像
            self.show_result(best_match_image, best_match_score, match_time)

        except Exception as e:
            print(f"错误：{str(e)}")
            self.result_label.setText(f"发生错误: {str(e)}")

    def build_dictionary(self, folder_path, num_clusters=50):
        """
        从给定文件夹中的图像中提取特征并使用KMeans聚类构建视觉词典。
        """
        sift = cv2.SIFT_create()
        all_descriptors = []

        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            if not filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                continue
            img = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)
            if img is None:
                continue
            kp, des = sift.detectAndCompute(img, None)
            if des is not None:
                all_descriptors.append(des)

        all_descriptors = np.vstack(all_descriptors)  # 将所有描述符合并
        print(f"提取了 {len(all_descriptors)} 个特征描述符，开始聚类...")

        # 使用KMeans聚类
        kmeans = KMeans(n_clusters=num_clusters)  # 使用sklearn的KMeans
        kmeans.fit(all_descriptors)

        # 保存词典
        self.dictionary = kmeans.cluster_centers_

    def get_feature_vector(self, img):
        """
        提取图像特征并生成与视觉词典的向量表示
        """
        sift = cv2.SIFT_create()
        kp, des = sift.detectAndCompute(img, None)

        if des is None:
            return np.zeros(len(self.dictionary))  # 如果没有特征，返回零向量

        # 为每个描述符找到最近的聚类中心
        labels = KMeans(n_clusters=len(self.dictionary)).fit_predict(des)

        # 统计每个聚类中心的出现次数
        feature_vector = np.zeros(len(self.dictionary))
        for label in labels:
            feature_vector[label] += 1

        return feature_vector

    def find_best_match(self, img1_vector, folder_path):
        """
        在文件夹中找到与图像特征向量最匹配的图像
        """
        best_match_score = float('inf')
        best_match_image = None
        best_match_img_path = None

        # 遍历文件夹中的所有图像文件
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            if not filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                continue

            img = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)
            if img is None:
                continue

            # 获取图像的特征向量
            img_vector = self.get_feature_vector(img)

            # 计算欧氏距离
            score = np.linalg.norm(img1_vector - img_vector)

            if score < best_match_score:
                best_match_score = score
                best_match_image = img
                best_match_img_path = file_path

        return best_match_image, best_match_score

    def show_result(self, best_match_image, best_match_score, match_time):
        """
        在界面上展示最匹配的图像和匹配得分
        """
        # 转换为RGB格式
        best_match_rgb = cv2.cvtColor(best_match_image, cv2.COLOR_BGR2RGB)

        # 将OpenCV图像转换为QPixmap
        match_pixmap = QPixmap.fromImage(QImage(best_match_rgb.data, best_match_rgb.shape[1], best_match_rgb.shape[0], best_match_rgb.strides[0], QImage.Format_RGB888))

        # 创建标签来显示图像
        match_label = QLabel(self)
        match_label.setPixmap(match_pixmap)

        # 清空旧的内容并显示新的结果
        self.result_label.setText(f"最匹配图像（匹配得分：{best_match_score:.2f}）")
        self.layout.addWidget(match_label)

        # 显示匹配时间
        self.time_label.setText(f"匹配时间：{match_time:.4f}秒")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ImageMatcher()
    window.show()
    sys.exit(app.exec_())