import cv2
import numpy as np
import time
import os


def load_images_from_folder(folder):
    """ 从文件夹加载所有图像 """
    images = {}
    for filename in os.listdir(folder):
        img_path = os.path.join(folder, filename)
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        if img is not None:
            images[filename] = img
    return images


def match_images(query_img_path, dataset_folder, method='SIFT'):
    """ 进行图像匹配 """
    if method not in ['SIFT', 'ORB']:
        raise ValueError("Method must be 'SIFT' or 'ORB'")

    query_img = cv2.imread(query_img_path, cv2.IMREAD_GRAYSCALE)
    if query_img is None:
        raise ValueError(f"Cannot load image: {query_img_path}")

    dataset_images = load_images_from_folder(dataset_folder)
    if not dataset_images:
        raise ValueError("No images found in dataset folder!")

    best_match = None
    best_score = float('-inf')
    best_match_img = None
    best_match_result = None
    match_time = None

    # 选择特征检测器
    detector = cv2.SIFT_create() if method == 'SIFT' else cv2.ORB_create()

    # 计算查询图像特征
    kp1, des1 = detector.detectAndCompute(query_img, None)
    if des1 is None or len(kp1) == 0:
        raise ValueError("No keypoints found in query image")

    # 选择匹配器
    matcher = cv2.BFMatcher(cv2.NORM_L2, crossCheck=True) if method == 'SIFT' else cv2.BFMatcher(cv2.NORM_HAMMING,
                                                                                                 crossCheck=True)

    start_time = time.time()

    for filename, img in dataset_images.items():
        kp2, des2 = detector.detectAndCompute(img, None)
        if des2 is None or len(kp2) == 0:
            continue  # 跳过无关键点的图片

        matches = matcher.match(des1, des2)
        matches = sorted(matches, key=lambda x: x.distance)

        # 避免除 0 错误
        valid_matches = [m for m in matches if m.distance > 0]
        score = sum([1 / (m.distance + 1e-6) for m in valid_matches[:50]]) if valid_matches else 0  # 取前50个匹配点

        if score > best_score:
            best_score = score
            best_match = filename
            best_match_img = img
            best_match_result = cv2.drawMatches(query_img, kp1, img, kp2, valid_matches[:50], None,
                                                flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

    end_time = time.time()
    match_time = end_time - start_time

    if best_match_result is None:
        raise ValueError("No valid matches found in dataset")

    return best_match, best_match_result, match_time