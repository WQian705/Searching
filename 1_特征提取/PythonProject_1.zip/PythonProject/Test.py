import sys
import cv2
import os
import traceback
from PyQt5.QtWidgets import QApplication, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QWidget, QFileDialog, QComboBox, QMessageBox
from PyQt5.QtGui import QPixmap, QImage
from match import match_images

class ImageMatcherApp(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("图像匹配系统")
        self.setGeometry(100, 100, 900, 600)

        # UI 组件
        self.select_btn = QPushButton("选择查询图像")
        self.select_btn.clicked.connect(self.load_query_image)

        self.method_selector = QComboBox()
        self.method_selector.addItems(["SIFT", "ORB"])

        self.match_btn = QPushButton("开始匹配")
        self.match_btn.clicked.connect(self.run_match)

        self.query_label = QLabel("查询图像")
        self.query_label.setFixedSize(400, 300)

        self.result_label = QLabel("最佳匹配图像")
        self.result_label.setFixedSize(400, 300)

        self.time_label = QLabel("匹配时间: --")

        # 布局
        layout = QVBoxLayout()
        top_layout = QHBoxLayout()
        bottom_layout = QHBoxLayout()

        top_layout.addWidget(self.select_btn)
        top_layout.addWidget(self.method_selector)
        top_layout.addWidget(self.match_btn)

        bottom_layout.addWidget(self.query_label)
        bottom_layout.addWidget(self.result_label)

        layout.addLayout(top_layout)
        layout.addLayout(bottom_layout)
        layout.addWidget(self.time_label)

        self.setLayout(layout)

        self.query_img_path = None
        self.dataset_folder = r"D:\Pycharm\Projects\PythonProject\A0C632"

    def load_query_image(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "选择查询图像", "", "Images (*.png *.jpg *.jpeg)")
        if file_path:
            self.query_img_path = file_path
            pixmap = QPixmap(file_path)
            self.query_label.setPixmap(pixmap.scaled(self.query_label.width(), self.query_label.height()))

    def run_match(self):
        if not self.query_img_path or not os.path.exists(self.dataset_folder):
            QMessageBox.critical(self, "错误", "请选择查询图像，并确保数据集路径存在！")
            return

        method = self.method_selector.currentText()
        try:
            best_match, match_img, match_time = match_images(self.query_img_path, self.dataset_folder, method)
            self.time_label.setText(f"最佳匹配: {best_match}, 耗时: {match_time:.4f} 秒")

            height, width, channel = match_img.shape
            bytes_per_line = 3 * width
            q_img = QImage(match_img.data, width, height, bytes_per_line, QImage.Format_RGB888)
            self.result_label.setPixmap(QPixmap.fromImage(q_img).scaled(self.result_label.width(), self.result_label.height()))

        except Exception as e:
            traceback.print_exc()  # 打印详细错误信息
            QMessageBox.critical(self, "匹配失败", str(e))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ImageMatcherApp()
    window.show()
    sys.exit(app.exec_())